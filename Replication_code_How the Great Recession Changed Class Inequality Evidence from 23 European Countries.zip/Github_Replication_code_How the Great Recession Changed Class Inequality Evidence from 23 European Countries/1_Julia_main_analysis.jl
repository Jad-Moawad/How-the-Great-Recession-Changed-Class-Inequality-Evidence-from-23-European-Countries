# Extract the packages
using Arrow, DataFrames, MixedModels, PooledArrays, FreqTables, Effects, GLM, RegressionTables, FixedEffectModels

# Extract the data  
cd("/Users/jmoawad/Desktop/Article 2 final submission")
dffnm = "df"
df = DataFrame(Arrow.Table(dffnm));
allowmissing!(df);

# Rename the variables
df1 = DataFrame(
    country = PooledArray(df.cntry),
    class = PooledArray(df.class),
    cyear = PooledArray(string.(df.cyear)),
    unemp = df.unemp,
    gap = df.gap,
    income2 = df.income2,
    income = df.income,
    age = df.age, 
    gender = PooledArray(string.(df.gender)),
    cbirth = df.cbirth,
    year = PooledArray(string.(df.year)));

# Prepare the data into grouping for "MixedModels"
contr = Dict(nm => Grouping() for nm in (:country, :cyear));

contr = Dict(:country => Grouping(),
             :cyear => Grouping(),
             :gender => DummyCoding(base="Female"),
             :year => DummyCoding(base="2007"),
             :class => DummyCoding(base="Upper-middle class"));

# Construct the models 
form1 = @formula income2 ~ 1 + gender + age  + cbirth + class*unemp + year+
                            (1|cyear)+
                            (1+class|country);

form2 = @formula income2 ~ 1 + gender + age  + cbirth + class*gap + year+
                            (1|cyear)+
                            (1+class|country);

# Run the models. See Table 1 and Table S3. Main effects and interaction effects with social class and macroeconomic shocks on labor income.
m1 = @time fit(MixedModel, form1, df1, contrasts=contr);
m2 = @time fit(MixedModel, form2, df1, contrasts=contr);

# Here you use the package "Effects" to get the predicted values of social class and unemployment rate (or GDP gap) on earnings. See Figure S2.
# You should then export manually these results to excel
using Effects

d1 = Dict(:class => ["Working class","Upper-middle class"],:unemp => [0:5; 6:25])
ave_unemp = effects(d1, m1);

d2 = Dict(:class => ["Working class","Upper-middle class"],:gap => [-9:5; 6:15])
ave_gap = effects(d2, m2);

# Construct the model of table S4 for unemplyoment rate
form3 = @formula income ~ 1 + gender + age  + cbirth + class*unemp + year+
                            (1|cyear)+
                            (1+class|country);

# Construct the model of table S4 for GDP gap
form4 = @formula income ~ 1 + gender + age  + cbirth + class*gap + year+
                            (1|cyear)+
                            (1+class|country);

# See table S4. Main effects and interaction effects with social class and macroeconomic shocks on non-logged labor income without bottom coding. 
m3 = @time fit(MixedModel, form3, df1, contrasts=contr);
m4 = @time fit(MixedModel, form4, df1, contrasts=contr);

# Run the fixed effects models. See Table S5. Main effects and interaction effects with social class and macroeconomic shocks on labor income – country fixed effects models.
m5= reg(df1, @formula(income2 ~ gender + age  + cbirth + class*unemp + fe(year)+ fe(country)), contrasts=contr);
m6= reg(df1, @formula(income2 ~ gender + age  + cbirth + class*gap + fe(year)+ fe(country)), contrasts=contr);

# Here i create eight new datasets with each excluding one of the largest eight countries.
df_de=df1[(df1.country .!= "DE"), :]
df_fr=df1[(df1.country .!= "FR"), :]
df_uk=df1[(df1.country .!= "UK"), :]
df_it=df1[(df1.country .!= "IT"), :]
df_es=df1[(df1.country .!= "ES"), :]
df_pl=df1[(df1.country .!= "PL"), :]
df_nl=df1[(df1.country .!= "NL"), :]
df_be=df1[(df1.country .!= "BE"), :];

# See Table S6. Main effects and interaction effects with social class and unemployment rate on labor income - excluding key countries from the sample.
DE = @time fit(MixedModel, form1, df_de, contrasts=contr)
FR = @time fit(MixedModel, form1, df_fr, contrasts=contr)
UK = @time fit(MixedModel, form1, df_uk, contrasts=contr)
IT = @time fit(MixedModel, form1, df_it, contrasts=contr)
ES = @time fit(MixedModel, form1, df_es, contrasts=contr)
PL = @time fit(MixedModel, form1, df_pl, contrasts=contr)
NL = @time fit(MixedModel, form1, df_nl, contrasts=contr)
BE = @time fit(MixedModel, form1, df_be, contrasts=contr);

# See Table S7. Main effects and interaction effects with social class and GDP gap on labor income- excluding key countries from the sample.
DE2 = @time fit(MixedModel, form2, df_de, contrasts=contr)
FR2 = @time fit(MixedModel, form2, df_fr, contrasts=contr)
UK2 = @time fit(MixedModel, form2, df_uk, contrasts=contr)
IT2 = @time fit(MixedModel, form2, df_it, contrasts=contr)
ES2 = @time fit(MixedModel, form2, df_es, contrasts=contr)
PL2 = @time fit(MixedModel, form2, df_pl, contrasts=contr)
NL2 = @time fit(MixedModel, form2, df_nl, contrasts=contr)
BE2 = @time fit(MixedModel, form2, df_be, contrasts=contr);

# Here I extract the results using RegressionTables package.
# Table 1 and Table S3
regtable(m1,m2; renderSettings = latexOutput())

# Table S4. Main effects and interaction effects with social class and macroeconomic shocks on non-logged labor income without bottom coding
regtable(m3,m4; renderSettings = latexOutput())

# Table S5. Main effects and interaction effects with social class and macroeconomic shocks on labor income – country fixed effects models.
regtable(m5,m6; renderSettings = latexOutput())

# Table S6. Supplementary sensitivity tests excluding key countries from the sample; main effects and interaction effects with social class and unemployment rate on labor income.
regtable(DE,FR,UK,IT,ES,PL,NL,BE; renderSettings = latexOutput())

# Table S7. Supplementary sensitivity tests excluding key countries from the sample; main effects and interaction effects with social class and GDP gap on labor income.
regtable(DE2,FR2,UK2,IT2,ES2,PL2,NL2,BE2; renderSettings = latexOutput())
