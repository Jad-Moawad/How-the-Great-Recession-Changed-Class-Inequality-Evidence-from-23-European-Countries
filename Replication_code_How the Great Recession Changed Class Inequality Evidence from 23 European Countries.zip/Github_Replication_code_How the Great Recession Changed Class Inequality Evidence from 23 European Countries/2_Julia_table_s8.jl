# Extract the packages
using Arrow, DataFrames, MixedModels, PooledArrays, FreqTables, Effects, GLM, RegressionTables

# Extract the data  
cd("/Users/jmoawad/Desktop/Article 2 final submission")
dffnm = "df_active"
df = DataFrame(Arrow.Table(dffnm));
allowmissing!(df);

# Rename the variables
df1 = DataFrame(
    country = PooledArray(df.cntry),
    class = PooledArray(df.class),
    cyear = PooledArray(string.(df.cyear)),
    unemp = df.unemp,
    gap = df.gap,
    income2 = df.income2,
    income = df.income,
    age = df.age, 
    gender = PooledArray(string.(df.gender)),
    cbirth = df.cbirth,
    year = PooledArray(string.(df.year)));

# Prepare the data into grouping for "MixedModels"
contr = Dict(nm => Grouping() for nm in (:country, :cyear));

contr = Dict(:country => Grouping(),
             :cyear => Grouping(),
             :gender => DummyCoding(base="Female"),
             :year => DummyCoding(base="2007"),
             :class => DummyCoding(base="Upper-middle class"));

# Construct the models 
form1 = @formula income2 ~ 1 + gender + age  + cbirth + class*unemp + year+
                            (1|cyear)+
                            (1+class|country);

form2 = @formula income2 ~ 1 + gender + age  + cbirth + class*gap + year+
                            (1|cyear)+
                            (1+class|country);

# Run the models. See Table S8. Main effects and interaction effects with social class and macroeconomic shocks on labor income – including the unemployed. 
m7 = @time fit(MixedModel, form1, df1, contrasts=contr);
m8 = @time fit(MixedModel, form2, df1, contrasts=contr);

# Extract in Latex. See Table S8. 
regtable(m7,m8; renderSettings = latexOutput())
