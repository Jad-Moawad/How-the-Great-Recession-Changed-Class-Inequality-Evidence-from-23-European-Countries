# Install the packages below in case they are not installed. 
# install.packages("tidyverse")
# install.packages("ggpubr")
 
library(tidyverse)
library(ggpubr)

# Clear the data environment
rm(list = ls())

# Extract the data saved at the end of script "0_setting_data.R"
load("directory_path_file/df.Rda")

# Create the mean of GDP gap by each country and year 
a=df
a = a %>%
  group_by(cntry2, year) %>%
  summarise(gap = mean(gap)) 

# Set year as numeric to create for it a range in ggplot 
a$year = as.numeric(levels(a$year))[a$year]

# Create six different categories of countries
ga <- filter(a, cntry2=="Greece" | cntry2=="Spain" | cntry2=="Italy" | cntry2=="Portugal") 
gb <- filter(a, cntry2=="France" | cntry2=="Belgium" | cntry2=="Luxembourg" | cntry2=="United Kingdom") 
gc <- filter(a, cntry2=="Austria" | cntry2=="Netherlands" | cntry2=="Germany" | cntry2=="Switzerland") 
gd <- filter(a, cntry2=="Czech Republic" | cntry2=="Hungary" | cntry2=="Poland" | cntry2=="Slovak Republic") 
ge <- filter(a, cntry2=="Estonia" | cntry2=="Iceland" | cntry2=="Ireland") 
gf <- filter(a, cntry2=="Denmark" | cntry2=="Finland" | cntry2=="Norway" | cntry2=="Sweden") 

# Plot each of these six categories separately
g1= ggplot(ga, aes(year, gap))+
  geom_line(aes(group=cntry2, linetype = cntry2), size=1.5)+
  geom_vline(xintercept=2008, color="black", linetype="dashed") +
  geom_hline(yintercept=0, color="black", linetype="dashed") +
  geom_point(aes(shape = factor(cntry2)), size= 5)+
  labs(group= "Country", shape= "Country", linetype= "Country") +
  xlab("Year") +  ylab(NULL) +
  scale_y_continuous(limits = c(-13, 17), breaks = seq(-12, 16, by = 3)) +
  scale_x_continuous(limits = c(2004, 2017), breaks = seq(2004, 2017, by = 3)) +
  theme_classic() +
  theme( 
    legend.key.size = unit(3,"line"),
    legend.position="bottom", legend.box="vertical", legend.margin=margin(),
    plot.caption = element_text(color = "black", size= 20, face = "bold"),
    axis.title.x = element_text(color="Black", size=26, face="bold"),
    axis.title.y = element_text(color="Black", size=26, face="bold"),
    legend.title =  element_blank(),
    legend.text = element_text(color = "Black", size = 25),
    axis.text.x = element_text(face="bold", color="black", size=24),
    axis.text.y = element_text(face="bold", color="black", size=24)
  )  + 
  guides(group = guide_legend(nrow = 2), 
         shape = guide_legend(nrow = 2),
         linetype = guide_legend(nrow = 2)) 

g2= ggplot(gb, aes(year, gap))+
  geom_line(aes(group=cntry2, linetype = cntry2), size=1.5)+
  geom_vline(xintercept=2008, color="black", linetype="dashed") +
  geom_hline(yintercept=0, color="black", linetype="dashed") +
  geom_point(aes(shape = factor(cntry2)), size= 5)+
  labs(group= "Country", shape= "Country", linetype= "Country") +
  xlab("Year") + ylab(NULL) +
  scale_y_continuous(limits = c(-13, 17), breaks = seq(-12, 16, by = 3)) +
  scale_x_continuous(limits = c(2004, 2017), breaks = seq(2004, 2017, by = 3)) +
  theme_classic() +
  theme( 
    legend.key.size = unit(3,"line"),
    legend.position="bottom", legend.box="vertical", legend.margin=margin(),
    plot.caption = element_text(color = "black", size= 20, face = "bold"),
    axis.title.x = element_text(color="Black", size=26, face="bold"),
    axis.title.y = element_text(color="Black", size=26, face="bold"),
    legend.title =  element_blank(),
    legend.text = element_text(color = "Black", size = 25),
    axis.text.x = element_text(face="bold", color="black", size=24),
    axis.text.y = element_text(face="bold", color="black", size=24)
  )  + 
  guides(group = guide_legend(nrow = 2), 
         shape = guide_legend(nrow = 2),
         linetype = guide_legend(nrow = 2)) 


g3= ggplot(gc, aes(year, gap))+
  geom_line(aes(group=cntry2, linetype = cntry2), size=1.5)+
  geom_vline(xintercept=2008, color="black", linetype="dashed") +
  geom_hline(yintercept=0, color="black", linetype="dashed") +
  geom_point(aes(shape = factor(cntry2)), size= 5)+
  labs(group= "Country", shape= "Country", linetype= "Country") +
  xlab("Year") +  ylab(NULL) +
  scale_y_continuous(limits = c(-13, 17), breaks = seq(-12, 16, by = 3)) +
  scale_x_continuous(limits = c(2004, 2017), breaks = seq(2004, 2017, by = 3)) +
  theme_classic() +
  theme( 
    legend.key.size = unit(3,"line"),
    legend.position="bottom", legend.box="vertical", legend.margin=margin(),
    plot.caption = element_text(color = "black", size= 20, face = "bold"),
    axis.title.x = element_text(color="Black", size=26, face="bold"),
    axis.title.y = element_text(color="Black", size=26, face="bold"),
    legend.title =  element_blank(),
    legend.text = element_text(color = "Black", size = 25),
    axis.text.x = element_text(face="bold", color="black", size=24),
    axis.text.y = element_text(face="bold", color="black", size=24)
  )  + 
  guides(group = guide_legend(nrow = 2), 
         shape = guide_legend(nrow = 2),
         linetype = guide_legend(nrow = 2)) 

g4= ggplot(gd, aes(year, gap))+
  geom_line(aes(group=cntry2, linetype = cntry2), size=1.5)+
  geom_vline(xintercept=2008, color="black", linetype="dashed") +
  geom_hline(yintercept=0, color="black", linetype="dashed") +
  geom_point(aes(shape = factor(cntry2)), size= 5)+
  labs(group= "Country", shape= "Country", linetype= "Country") +
  xlab("Year") + ylab(NULL)  +
  scale_y_continuous(limits = c(-13, 17), breaks = seq(-12, 16, by = 3)) +
  scale_x_continuous(limits = c(2004, 2017), breaks = seq(2004, 2017, by = 3)) +
  theme_classic() +
  theme( 
    legend.key.size = unit(3,"line"),
    legend.position="bottom", legend.box="vertical", legend.margin=margin(),
    plot.caption = element_text(color = "black", size= 20, face = "bold"),
    axis.title.x = element_text(color="Black", size=26, face="bold"),
    axis.title.y = element_text(color="Black", size=26, face="bold"),
    legend.title =  element_blank(),
    legend.text = element_text(color = "Black", size = 25),
    axis.text.x = element_text(face="bold", color="black", size=24),
    axis.text.y = element_text(face="bold", color="black", size=24)
  )  + 
  guides(group = guide_legend(nrow = 2), 
         shape = guide_legend(nrow = 2),
         linetype = guide_legend(nrow = 2)) 

g5=ggplot(ge, aes(year, gap))+
  geom_line(aes(group=cntry2, linetype = cntry2), size=1.5)+
  geom_vline(xintercept=2008, color="black", linetype="dashed") +
  geom_hline(yintercept=0, color="black", linetype="dashed") +
  geom_point(aes(shape = factor(cntry2)), size= 5)+
  labs(group= "Country", shape= "Country", linetype= "Country") +
  xlab("Year") +  ylab(NULL) +
  scale_y_continuous(limits = c(-13, 17), breaks = seq(-12, 16, by = 3)) +
  scale_x_continuous(limits = c(2004, 2017), breaks = seq(2004, 2017, by = 3)) +
  theme_classic() +
  theme( 
    legend.key.size = unit(3,"line"),
    legend.position="bottom", legend.box="vertical", legend.margin=margin(),
    plot.caption = element_text(color = "black", size= 20, face = "bold"),
    axis.title.x = element_text(color="Black", size=26, face="bold"),
    axis.title.y = element_text(color="Black", size=26, face="bold"),
    legend.title =  element_blank(),
    legend.text = element_text(color = "Black", size = 25),
    axis.text.x = element_text(face="bold", color="black", size=24),
    axis.text.y = element_text(face="bold", color="black", size=24)
  )  + 
  guides(group = guide_legend(nrow = 2), 
         shape = guide_legend(nrow = 2),
         linetype = guide_legend(nrow = 2)) 

g6= ggplot(gf, aes(year, gap))+
  geom_line(aes(group=cntry2, linetype = cntry2), size=1.5)+
  geom_vline(xintercept=2008, color="black", linetype="dashed") +
  geom_hline(yintercept=0, color="black", linetype="dashed") +
  geom_point(aes(shape = factor(cntry2)), size= 5)+
  labs(group= "Country", shape= "Country", linetype= "Country") +
  xlab("Year") + ylab(NULL)  +
  scale_y_continuous(limits = c(-13, 17), breaks = seq(-12, 16, by = 3)) +
  scale_x_continuous(limits = c(2004, 2017), breaks = seq(2004, 2017, by = 3)) +
  theme_classic() +
  theme( 
    legend.key.size = unit(3,"line"),
    legend.position="bottom", legend.box="vertical", legend.margin=margin(),
    plot.caption = element_text(color = "black", size= 20, face = "bold"),
    axis.title.x = element_text(color="Black", size=26, face="bold"),
    axis.title.y = element_text(color="Black", size=26, face="bold"),
    legend.title =  element_blank(),
    legend.text = element_text(color = "Black", size = 25),
    axis.text.x = element_text(face="bold", color="black", size=24),
    axis.text.y = element_text(face="bold", color="black", size=24)
  )  + 
  guides(group = guide_legend(nrow = 2), 
         shape = guide_legend(nrow = 2),
         linetype = guide_legend(nrow = 2)) 

# Gather all graphs together in one plot
setwd("directory_path_file")
figure1 <- ggarrange(g1, g2, g3, g4, g5,g6, ncol=2, nrow=3)
ggsave("Figure_S1.pdf", scale=1.35, width = 17, height = 20, dpi= 2300,limitsize = FALSE,units = c("in"))


