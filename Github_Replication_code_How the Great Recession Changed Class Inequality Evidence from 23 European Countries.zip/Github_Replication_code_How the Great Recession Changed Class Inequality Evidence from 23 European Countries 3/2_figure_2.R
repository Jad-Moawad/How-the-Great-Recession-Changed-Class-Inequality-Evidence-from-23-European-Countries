# Install the packages below in case they are not installed. 
# install.packages("ggplot2")
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("readxl")

library(ggplot2)
library(tidyverse)
library(ggpubr)
library(readxl)

# Clear the data environment
rm(list = ls())

# Extract the predicted values manually from Julia to excel, then to R. 
# The results of the predicted values are extracted from Julia using the Effects.jl package 

a1 <- read_excel("directory_path_file/predicted_values.xlsx", sheet = "Sheet1")
a1=filter(a1,unemp==3|unemp==6|unemp==9|unemp==12|unemp==15|unemp==18)

# Calculate the class gap in predicted values of labor income by unemployment rate
x2= a1 %>%
  group_by(unemp) %>%
  mutate(est = income2[class == "Upper-middle class"] - income2,
         cil = lower[class == "Upper-middle class"] - lower,
         cih = upper[class == "Upper-middle class"] - upper) %>%
  filter(class != "Upper-middle class") 

x2 <- x2 %>% dplyr::select(-c("income2","lower","upper", "err"))

g1=ggplot(x2,aes(unemp, est)) +
  geom_text(data = filter(x2, est == max(x2$est)), aes(unemp, est, label = round(est, 3)), hjust = -0.25, size=7) +
  geom_text(data = filter(x2, est == min(x2$est)),  aes(unemp, est, label = round(est, 3)), hjust = 1.25, size=7) +
  geom_point(aes(unemp,est), size=4, color= "black") +
  geom_line(size= 1.5, color = "black") +
  xlab("Unemployment")+ ylab(NULL) +
  coord_cartesian(xlim = c(1, 20))+ 
  scale_x_continuous(limits = c(1, 20), breaks = seq(3, 18, by = 3))+
  scale_y_continuous(limits = c(.48, 0.85), breaks = seq(.50, 0.8, by = 0.1))+
  theme_classic()+
  theme( 
    axis.title.x = element_text(color="Black", size=28),
    axis.title.y = element_text(color="Black", size=28, hjust = 0.5),
    plot.title = element_text(hjust = 0.5, color="Black", size=28),
    legend.title = element_text(color = "Black", size = 22),
    legend.text = element_text(color = "Black", size = 16),
    legend.position="bottom",
    axis.text.x = element_text(color="black", size=28),
    axis.text.y = element_text(color="black", size=28),
    strip.text = element_text( size=20)
  )

# Extract the predicted values of manually from Julia to excel. The results of the predicted values are extracted from Julia using the Effects.jl package 
a2 <- read_excel("directory_path_file/predicted_values.xlsx", sheet = "Sheet2")

# Calculate the class gap in predicted values of labor income by GDP gap
a2=filter(a2,gap==-6|gap==-3|gap==0|gap==3|gap==6|gap==9|gap==12)
x2= a2 %>%
  group_by(gap) %>%
  mutate(est = income2[class == "Upper-middle class"] - income2)%>%
  filter(class=="Working class")

x2 <- x2 %>% dplyr::select(c("est", "gap"))


g2=ggplot(x2,aes(x=gap, y=est)) +
  geom_point(size=4, shape=15, color= "gray60") +
  geom_line(size= 1.5, color = "gray60")+
  geom_text(data = filter(x2, est == max(x2$est)), aes(gap, est, label = round(est, 3)), hjust = -0.25, size=7) +
  geom_text(data = filter(x2, est == min(x2$est)),  aes(gap, est, label = round(est, 3)), hjust = 1.25, size=7) +
  xlab("GDP gap")+ ylab(NULL) +
  coord_cartesian(xlim = c(-8, 14))+ 
  scale_x_continuous(limits = c(-8, 14), breaks = seq(-6, 12, by = 3))+
  scale_y_continuous(limits = c(.46, 0.85), breaks = seq(.50, 0.8, by = 0.1))+
  theme_classic()+
  theme( 
    axis.title.x = element_text(color="Black", size=28),
    axis.title.y = element_text(color="Black", size=28, hjust = 0.5),
    plot.title = element_text(hjust = 0.5, color="Black", size=28),
    legend.title = element_text(color = "Black", size = 22),
    legend.text = element_text(color = "Black", size = 16),
    legend.position="bottom",
    axis.text.x = element_text(color="black", size=28),
    axis.text.y = element_text(color="white", size=28),
    strip.text = element_text( size=20),
    axis.ticks.y = element_blank())

# Gather both figures together and extract them to a certain path file
setwd("directory_path_file/Figures")
figure1_ <- ggarrange(g1, g2, ncol=2, nrow=1)
ggsave("Figure_2.pdf", scale=1.35, width = 12, height =5, dpi= 2300,limitsize = FALSE,units = c("in"))

