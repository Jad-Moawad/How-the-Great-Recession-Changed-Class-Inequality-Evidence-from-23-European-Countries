# Replication package for "How the Great Recession Changed Class Inequality: Evidence from 23 European Countries" 
# Journal: Social Science Research. Author: Jad Moawad
# October 2022
# See readme.rtf for further instructions
# This file compiles data from the European Union Statistics on Income and Living Conditions (EU-SILC) 

# Install the packages below in case they are not installed 
# install.packages("dplyr")
# install.packages("tidyr")
# install.packages("haven")
 
# Extract the packages
library(dplyr)
library(tidyr)
library(haven)

# Gather all the EU-SILC cross-sectional data in one folder to import the data
silc04 <- read_dta("directory_path_file/cross2004p.dta")
s04=select(silc04,PB020,PB110,PB140,PB150,PL050,PB210,PL030,PY010G)
rm(silc04)
silc05 <- read_dta("directory_path_file/cross2005p.dta")
s05=select(silc05,PB020,PB110,PB140,PB150,PL050,PB210,PL030,PY010G)
rm(silc05)
silc06 <- read_dta("directory_path_file/cross2006p.dta")
s06=select(silc06,PB020,PB110,PB140,PB150,PL050,PB210,PL030,PY010G)
rm(silc06)
silc07 <- read_dta("directory_path_file/cross2007p.dta")
s07=select(silc07,PB020,PB110,PB140,PB150,PL050,PB210,PL030,PY010G)
rm(silc07)
silc08 <- read_dta("directory_path_file/cross2008p.dta")
s08=select(silc08,PB020,PB110,PB140,PB150,PL050,PB210,PL030,PY010G)
rm(silc08)
silc09 <- read_dta("directory_path_file/cross2009p.dta")
s09=select(silc09,PB020,PB110,PB140,PB150,PL050,PB210,PL030,PL031,PY010G)
rm(silc09)
silc10 <- read_dta("directory_path_file/cross2010p.dta")
s10=select(silc10,PB020,PB110,PB140,PB150,PL050,PB210,PL030,PL031,PY010G)
rm(silc10)
silc11 <- read_dta("directory_path_file/cross2011p.dta")
s11=select(silc11,PB020,PB110,PB140,PB150,PL050,PB210,PL031,PL051,PY010G)
rm(silc11)
silc12 <- read_dta("directory_path_file/cross2012p.dta")
s12=select(silc12,PB020,PB110,PB140,PB150,PL051,PB210,PL031,PY010G)
rm(silc12)
silc13 <- read_dta("directory_path_file/cross2013p.dta")
s13=select(silc13,PB020,PB110,PB140,PB150,PL051,PB210,PL031,PY010G)
rm(silc13)
silc14 <- read_dta("directory_path_file/cross2014p.dta")
s14=select(silc14,PB020,PB110,PB140,PB150,PL051,PB210,PL031,PY010G)
rm(silc14)
silc15 <- read_dta("directory_path_file/cross2015p.dta")
s15=select(silc15,PB020,PB110,PB140,PB150,PL051,PB210,PL031,PY010G)
rm(silc15)
silc16 <- read_dta("directory_path_file/cross2016p.dta")
s16=select(silc16,PB020,PB110,PB140,PB150,PL051,PB210,PL031,PY010G)
rm(silc16)
silc17 <- read_dta("directory_path_file/cross2017p.dta")
s17=select(silc17,PB020,PB110,PB140,PB150,PL051,PB210,PL031,PY010G)
rm(silc17)

# Gather all data
s=bind_rows(s04,s05,s06,s07,s08,s09,s10,s11,s12,s13,s14,s15,s16,s17)

# Drop some data sets to not overload your CPU
rm(s04,s05,s06,s07,s08,s09,s10,s11,s12,s13,s14,s15,s16,s17)

# Rename your variables
s= rename(s, cntry = PB020,
          year= PB110,
          birth= PB140,
          gender= PB150,
          incomeg= PY010G,
          occ_a= PL050,
          occ_b= PL051,
          cbirth= PB210,
          status_a= PL030,
          status_b= PL031)

s= select(s,cntry,year,birth,gender,incomeg,occ_a,occ_b,cbirth,status_a,status_b)

# Rename Greece the same country code across all modules
s$cntry[s$cntry == "GR"] <- "EL"

# Pick up countries based on macro indicators availability 
s=filter(s,cntry!="BG"&cntry!="CY"&cntry!="HR"&cntry!="LT"&cntry!="MT"&cntry!="LV"&cntry!="RO"&cntry!="RS"&cntry!="SI")

# All variables coded below 11 are either police officers or coded not according to the 2 ISCO-digits, thus they are left out           
s = s %>% mutate(occ_a = ifelse(occ_a>10, occ_a, NA_real_))               
s = s %>% mutate(occ_b = ifelse(occ_b>10, occ_b, NA_real_))               
s= s %>%mutate(isco = coalesce(occ_a, occ_b))


# Create a social class variable 
s=s %>% mutate(class = case_when(isco>=11 & isco<=29~ 1,
                                 isco>=30 & isco<=49  ~ 2, 
                                 isco>=50 & isco<=99  ~ 3, TRUE ~ NA_real_)) 
s$class <- factor(s$class,
                  levels = c(1,2,3),
                  labels = c("Upper-middle class","Lower-middle class","Working class"))

# Create a gender variable  
s$gender = factor(s$gender,
                  levels = c(1,2),
                  labels = c("Male", "Female"))

# Create a country of birth variable
s$cbirth <- gsub(",","",s$cbirth)
s$cbirth = as.numeric(as.factor(s$cbirth))

s=s %>% mutate(cbirth = case_when(cbirth==3 ~ 1,
                                  cbirth==2 ~ 2, 
                                  cbirth==4 ~ 3, TRUE ~ NA_real_)) 

s$cbirth <- factor(s$cbirth,
                   levels = c(1, 2, 3),
                   labels = c("Country of citizenship","EU", "Outside EU"))

# Keep people aged between 25 and 64
s$age= s$year - s$birth
s= filter(s, age>=25 & age<=64)

# Import CPI and correct for inflation
library(readxl)
cpi_ <- read_excel("Download CPI.xlsx from my Github page and include its path file here")
cpi <- tidyr::gather(cpi_, key = year, value = cpi, `2004`:`2017`)
s <- merge(s, cpi, by=c("cntry","year")) 
s$income = (s$incomeg/s$cpi)*100            

# Create a country-year variable
s <- s %>%
  unite(cyear1, cntry, year, sep="_", remove = FALSE)
s$cyear <- as.factor(s$cyear1)
s$cyear <- as.integer(s$cyear)

# Harmonize the coding of employment status between 2011 and 2017 similar to the one of the period that preceded it
s=s %>% mutate(status_ = case_when(status_b==1 | status_b==3  ~ 1,status_b==2 | status_b==4 ~ 2,
                                   status_b==5 ~ 3,  status_b==6 ~ 4 , status_b== 7 ~ 5,
                                   status_b==8 ~ 6,  status_b== 9 ~ 7, status_b== 10~ 8,
                                   status_b==11 ~ 9, TRUE ~ NA_real_)) 
s= s %>%mutate(status = coalesce(status_a, status_))

# Create other variables for country that has either 3 letter code or full name 
s=s %>%  dplyr::mutate(cntry3 = forcats::fct_recode(cntry,"AUT" = "AT","BEL" = "BE",
                                                    "CHE" = "CH", "CZE" = "CZ", "DEU" = "DE", "DNK" = "DK",
                                                    "EST" = "EE", "GRC" = "EL","ESP" = "ES", "FIN" = "FI", "FRA" = "FR",
                                                    "HUN" = "HU", "IRL" = "IE", "ISL" = "IS", "ITA" = "IT", "LUX"= "LU",
                                                    "NLD" = "NL", "NOR"= "NO","POL" = "PL", "PRT" = "PT", "SWE" = "SE",
                                                    "SVK" = "SK", "GBR" = "UK"))

s=s %>%  dplyr::mutate(cntry2 = forcats::fct_recode(cntry,"Austria" = "AT","Belgium" = "BE",
                                                    "Switzerland" = "CH", "Czech Republic" = "CZ", "Germany" = "DE", "Denmark" = "DK",
                                                    "Estonia" = "EE", "Greece" = "EL","Spain" = "ES", "Finland" = "FI", "France" = "FR",
                                                    "Hungary" = "HU", "Ireland" = "IE", "Iceland" = "IS", "Italy" = "IT", "Luxembourg"= "LU",
                                                    "Netherlands" = "NL", "Norway"= "NO","Poland" = "PL", "Portugal" = "PT", "Sweden" = "SE",
                                                    "Slovak Republic" = "SK", "United Kingdom" = "UK"))

# Import macro indicators and merge them with the data set
library(readxl)
macro_ind = read_excel("Download macro_indcators.xlsx from my Github page and include its path file here.xlsx")
s <- merge(s, macro_ind, by=c("cntry","year")) 

# Fix 2007 as a base_category
s$year = as.factor(s$year)
s$year <- relevel(s$year, "2007")

s$cntry = as.factor(s$cntry)
s$cyear = as.factor(s$cyear)

# Keep the working population
d1=filter(s,status<=2)

# Bottom coding - any value below 15% of the median is equal to 15% of the median. Then log the income variable         
d1 = d1 %>% dplyr::group_by(cyear) %>% dplyr::mutate(income2 = ifelse(income < (0.15* median(income,na.rm = T)), (0.15* median(income,na.rm = T)), income))              
d1$income2 = log(d1$income2)

# Keep the active population, this means we add the unemployed here
d2=filter(s,status<=3)

# Bottom coding - any value below 15% of the median is equal to 15% of the median. The median in 2012 in Greece is equal to 0, thus take the 15% of the mean in that year instead of the median. Then log the income variable  
d3 = filter(d2,cntry!="EL"| year!=2012)
d4 = filter(d2,cntry=="EL"& year==2012)
d3 = d3 %>% dplyr::group_by(cyear) %>% dplyr::mutate(income2 = ifelse(income < (0.15* median(income,na.rm = T)), (0.15* median(income,na.rm = T)), income))              
d4 = d4 %>% dplyr::group_by(cyear) %>% dplyr::mutate(income2 = ifelse(income < (0.15* mean(income,na.rm = T)), (0.15* mean(income,na.rm = T)), income))              
d5=bind_rows(d3,d4)

d5$income2 = log(d5$income2)

# Keep only variables of interest
df=select(d1,income2,income,cntry,cntry2,class,age,gender,cbirth,year,cyear,unemp,gap)
df_active=select(d5,income2,income,cntry,cntry2,class,age,gender,cbirth,year,cyear,unemp,gap)

## Extract data in format that can be used using R software.

# This data set will be used for Figure S5
save(df_active,file="directory_path_file/df_active.Rda")

# This data set will be used for all the remaining analysis
save(df,file="directory_path_file/df.Rda")


## Extract data in format that can be used using Julia software.
#install.packages("arrow")
library(arrow) 

# This data set will be used for Table S8 
setwd("directory_path_file")
write_feather(df_active,'df_active')

# This data set will be used for all the remaining analysis
setwd("directory_path_file")
write_feather(df,'df')
