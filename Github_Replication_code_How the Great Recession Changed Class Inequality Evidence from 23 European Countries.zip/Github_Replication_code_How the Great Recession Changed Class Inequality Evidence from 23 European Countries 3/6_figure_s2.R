# Install the packages below in case they are not installed. 
# install.packages("ggplot2")
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("readxl")

library(ggplot2)
library(tidyverse)
library(ggpubr)
library(readxl)

# Clear the data environment
rm(list = ls())

# Extract the predicted values of manually from Julia to excel. The results of the predicted values are extracted from Julia using the Effects.jl package 
a1 <- read_excel("directory_path_file/predicted_values.xlsx", sheet = "Sheet1")

a1=filter(a1,unemp==3|unemp==6|unemp==9|unemp==12|unemp==15|unemp==18)
p1=ggplot(a1, aes(unemp, income2, group = class, shape= class, linetype=class)) + 
  geom_point(position=position_dodge(width=0.15)) +
  geom_errorbar(aes(ymin = lower, ymax = upper),width = 0.1,
                linetype = "solid",position=position_dodge(width=0.3))+
  geom_line(position=position_dodge(width=0.15)) + 
  scale_x_continuous(limits = c(1, 20), breaks = seq(3, 18, by = 3))+
  theme_classic()+
  xlab("Unemployment")+ ylab(NULL) + ggtitle(NULL) +
  theme( 
    axis.title.x = element_text(color="Black", size=28),
    axis.title.y = element_text(color="Black", size=28, hjust = 0.5),
    plot.title = element_text(hjust = 0.5, color="Black", size=28),
    legend.title = element_blank(),
    legend.text = element_text(color = "Black", size = 16),
    legend.position="bottom",
    axis.text.x = element_text(color="black", size=28),
    axis.text.y = element_text(color="black", size=28),
    strip.text = element_text( size=20)
  )

# Extract the predicted values of manually from Julia to excel. The results of the predicted values are extracted from Julia using the Effects.jl package 
a2 <- read_excel("directory_path_file/predicted_values.xlsx", sheet = "Sheet2")

a2=filter(a2,gap==-6|gap==-3|gap==0|gap==3|gap==6|gap==9|gap==12)
p2=ggplot(a2, aes(gap, income2, group = class, shape= class,linetype=class)) + 
  geom_point(position=position_dodge(width=0.15)) +
  geom_errorbar(aes(ymin = lower, ymax = upper),width = 0.1,
                linetype = "solid",position=position_dodge(width=0.3))+
  geom_line(position=position_dodge(width=0.15)) + 
  scale_x_continuous(limits = c(-8, 14), breaks = seq(-6, 12, by = 3))+
  theme_classic()+
  xlab("GDP gap")+ ylab(NULL) + ggtitle(NULL) +
  theme( 
    axis.title.x = element_text(color="Black", size=28),
    axis.title.y = element_text(color="Black", size=28, hjust = 0.5),
    plot.title = element_text(hjust = 0.5, color="Black", size=28),
    legend.title = element_blank(),
    legend.text = element_text(color = "Black", size = 16),
    legend.position="bottom",
    axis.text.x = element_text(color="black", size=28),
    axis.text.y = element_text(color="white", size=28),
    strip.text = element_text( size=20),
    axis.ticks.y = element_blank())

# Gather both figures together
setwd("directory_path_file/Figures")
figure1_ <- ggarrange(p1, p2, ncol=2, nrow=1)
ggsave("Figure_S2.pdf", scale=1.35, width = 12, height = 5, dpi= 2300,limitsize = FALSE,units = c("in"))

