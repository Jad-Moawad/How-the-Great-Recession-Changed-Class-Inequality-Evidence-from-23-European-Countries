# Install the packages below in case they are not installed. 
# install.packages("dplyr")
# install.packages("modelsummary")

library(dplyr)
library(modelsummary)

# Clear the data environment
rm(list = ls())

# Import the merged data set that is constructed in "0_setting_data"
load("directory_path_file/df.Rda")
a = df

# Select the variables of interest
a <- df %>% dplyr::select(c("unemp", "gap", "income2", "age", "gender", 
                            "class", "cbirth"))


# Transform your variables to include them in your table
a$gender = as.numeric(a$gender)
a$class = as.numeric(a$class)
a$cbirth = as.numeric(a$cbirth)

a$wc = ifelse(a$class == 3, 1, 0) 
a$mc = ifelse(a$class == 2, 1, 0) 
a$hc = ifelse(a$class == 1, 1, 0) 

a$oth = ifelse(a$cbirth == 3, 1, 0) 
a$eu = ifelse(a$cbirth == 2, 1, 0) 
a$re = ifelse(a$cbirth == 1, 1, 0) 

a$gender = ifelse(a$gender == 1, 1, 0) 

a <-a %>% rename('Unemployment' = unemp,
                 'GDP gap' = gap,
                 'Earnings (log scale)'= income2,
                 'Age' = age,
                 'Working class'= wc,
                 'Lower-middle class'= mc,
                 'Upper-middle class'= hc,
                 'Resident'= re,
                 'EU'= eu,
                 'Other countries'= oth,
                 'Male'=gender)

# Add references above certain rows
rows <- tribble(~term, ~France, ~Germany, 
                'Class' ,'' , '', 
                'Country of Birth' ,'' , '',
                'Macro predictors' ,'' , '',)
attr(rows, 'position') <- c(4, 8,12)

#  Extract to Latex output
datasummary(Male + Age + `Earnings (log scale)` + `Working class`+ `Lower-middle class`
            + `Upper-middle class`+ Resident + EU +  `Other countries` + `GDP gap` + Unemployment ~ (Mean+SD),
            sparse_header = FALSE, output = 'latex', data = a)
#  Extract to Microsoft word output 
datasummary(Male + Age + `Earnings (log scale)` + `Working class`+ `Lower-middle class`
            + `Upper-middle class`+ Resident + EU +  `Other countries` + `GDP gap` + Unemployment ~ (Mean+SD),
            sparse_header = FALSE, output = 'directory_path_file/Table_s1.docx', data = a, add_rows =  rows)

