# Install the packages below in case they are not installed. 
# install.packages("broom")
# install.packages("ggplot2")
# install.packages("tidyverse")
# install.packages("gridExtra")

library(broom)
library(ggplot2)
library(tidyverse)
library(gridExtra)

# Clear the data environment
rm(list = ls())

# Import the merged data set that is constructed in "0_setting_data"
load("directory_path_file/df.Rda")
a = df

# Create a loop to run the models by each country
temp <- a %>%
  group_by(cntry) %>%
  do(model1 = tidy(lm(income2 ~ age + gender+ cbirth + year*class, data = .), conf.int=TRUE)) %>%   
  unnest() 

# Extract the coefficients of interest
x= filter(temp, term=="year2008:classWorking class" | term=="year2009:classWorking class"| term=="year2010:classWorking class"| term=="year2011:classWorking class"| term=="year2012:classWorking class"
          | term=="year2013:classWorking class"| term=="year2014:classWorking class"| term=="year2015:classWorking class"| term=="year2016:classWorking class" | term=="year2017:classWorking class")

x=x %>%  dplyr::mutate(term = forcats::fct_recode(term,"2008" = "year2008:classWorking class","2009" = "year2009:classWorking class",
                                                  "2010" ="year2010:classWorking class", "2011" = "year2011:classWorking class", "2012" = "year2012:classWorking class", "2013" = "year2013:classWorking class",
                                                  "2014" = "year2014:classWorking class","2015" = "year2015:classWorking class", "2016" = "year2016:classWorking class", "2017" = "year2017:classWorking class"))

# Categorize countries to three different status: 1) widening gap, 2) stability, and 3) contracting gap
x$cat <- ifelse(x$cntry == "ES" | x$cntry == "IT"| x$cntry == "PT"| x$cntry == "EL" | x$cntry == "NL"
                | x$cntry == "AT" | x$cntry == "IE" | x$cntry == "DK"
                | x$cntry == "BE" | x$cntry == "FR" | x$cntry == "FI"
                | x$cntry == "DE"
                | x$cntry == "CH", "Widening gap", 
                ifelse(x$cntry == "UK" | x$cntry == "CZ" |x$cntry == "IS" |x$cntry == "EE" |x$cntry == "SE"
                       | x$cntry == "NO", "Stability", "Contracting gap")) 

x$cat_f = as.factor(x$cat)
x$cat_f  = factor(x$cat_f, levels=c("Widening gap",'Stability','Contracting gap'))

# Create a first raw version of the figure without adding the colors yet
p1= x %>%
  mutate(cntry = fct_relevel(cntry, levels=c( "IT","ES","PT","EL","IE","AT","FI","NL","FR","BE", 
                                              "DE","CH","DK","SE","NO","CZ", 
                                              "UK","IS","EE","SK","HU","LU","PL")),
         term = fct_relevel(term, levels=c("2017", "2016", "2015", "2014", "2013","2012", 
                                           "2011", "2010", "2009", "2008"))) %>%
  ggplot(aes(x= estimate, y=term)) +
  geom_text(aes(label = cntry, x =  Inf, y = Inf), vjust = 1.75, hjust =1, size=8.5)+
  geom_linerange(mapping=aes(xmin=conf.low , xmax=conf.high), width=0.1, size=.1, color="black") +
  geom_point(mapping=aes(x=estimate, y=term)) +
  geom_vline(xintercept=0, linetype = 1) +
  facet_wrap(vars(cntry,cat_f,scales="free"))+
  scale_y_discrete(breaks=c("2008","2009","2010", "2011","2012","2013", "2014","2015","2016","2017"),
                   labels=c("2008","","", "","2012","", "","","","2017")) +
  theme_classic() +
  ylab("Year") + xlab("Log earnings") +
  theme( 
    axis.title.x = element_text(color="Black", size=28, face="bold"),
    axis.title.y = element_text(color="Black", size=28, face="bold", angle=90, vjust = 0.5),
    plot.title = element_text(hjust = 0.5, color="Black", size=28, face="bold"),
    legend.text = element_text(color = "Black", size = 16, face="bold"),
    axis.text.x = element_text(color="black", size=12),
    axis.text.y = element_text(color="black", size=18),
    axis.ticks.y = element_blank()) 


# Create a separate version that adds a color to each country depending on their status.
dummy= x %>%
  mutate(cntry = fct_relevel(cntry, levels=c( "IT","ES","PT","EL","IE","AT","FI","NL","FR","BE", 
                                              "DE","CH","DK","SE","NO","CZ", 
                                              "UK","IS","EE","SK","HU","LU","PL")),
         term = fct_relevel(term, levels=c("2017", "2016", "2015", "2014", "2013","2012", 
                                           "2011", "2010", "2009", "2008"))) %>%
  ggplot(aes(x = estimate, y = term))+ 
  labs(fill= NULL)+
  facet_wrap(vars(cntry,cat_f,scales="free"))+
  geom_rect(aes(fill=cat_f), xmin=-Inf, xmax=Inf, ymin=-Inf, ymax=Inf) +
  scale_fill_manual(values=c("snow3", "gray60", "black"))+
  scale_y_discrete(breaks=c("2008","2009","2010", "2011","2012","2013", "2014","2015","2016","2017"),
                   labels=c("2008","","", "","2012","", "","","","2017")) +
  theme(strip.background = element_blank(),
        strip.text.x = element_text(margin = margin(.0001,100,.0001,5, "cm")),
        legend.text = element_text(color = "Black", size = 16))

g1 <- ggplotGrob(p1)
g2 <- ggplotGrob(dummy)

gtable_select <- function (x, ...) 
{
  matches <- c(...)
  x$layout <- x$layout[matches, , drop = FALSE]
  x$grobs <- x$grobs[matches]
  x
}

panels <- grepl(pattern="panel", g2$layout$name)
strips <- grepl(pattern="strip-t", g2$layout$name)
g2$layout$t[panels] <- g2$layout$t[panels] - 1
g2$layout$b[panels] <- g2$layout$b[panels] - 1

new_strips <- gtable_select(g2, panels | strips)

gtable_stack <- function(g1, g2){
  g1$grobs <- c(g1$grobs, g2$grobs)
  g1$layout <- transform(g1$layout, z= z-max(z), name="g2")
  g1$layout <- rbind(g1$layout, g2$layout)
  g1
}

new_plot <- gtable_stack(g1, new_strips)


# Extract only the legend from "dummy" plot
g_legend <- function(dummy){ 
  tmp <- ggplot_gtable(ggplot_build(dummy)) 
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box") 
  legend <- tmp$grobs[[leg]] 
  return(legend)} 

# Assign the legend to a separate object
facet.legend <- g_legend(dummy)

# Save the figure
setwd("directory_path_file/Figures")
jpeg("Figure_3.jpg", width = 15, height = 17, units = "in", res = 300)
print(grid.arrange(new_plot, facet.legend, nrow = 2, widths = c(7, 1), heights = c(0.1, 0.01)))
dev.off()

